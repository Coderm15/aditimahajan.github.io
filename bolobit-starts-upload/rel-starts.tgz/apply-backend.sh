#!/bin/bash
# D-54 start counting: 5 replaced backend files + 1 new (models/SurveyStart.js).
# Checks every replaced server file is still the last released version (OPS §10.1 item 10),
# and that the new file does not exist yet, before touching anything.
set -euo pipefail
REL=$(cd "$(dirname "$0")" && pwd); B=/home/ubuntu/backend/src; KEEP=/home/ubuntu/backend/_replaced-20261124-starts
declare -A PRE=( [controllers/publicSurveyController.js]=83eb18af7c63 [models/SurveyResponse.js]=9907018d673c [models/SurveyReport.js]=f1564ae629b8 [services/surveyReport.js]=d72e4d5833c3 [routes/public.js]=353d69172efb )
declare -A NEW=( [controllers/publicSurveyController.js]=7e73d1a449dc [models/SurveyResponse.js]=bcb03f7de236 [models/SurveyReport.js]=51c1cd649011 [services/surveyReport.js]=a1211b7196d9 [routes/public.js]=130caa6f02e5 [models/SurveyStart.js]=cabda136d9c9 )
for f in "${!PRE[@]}"; do got=$(sha256sum "$B/$f" | cut -c1-12); [ "$got" = "${PRE[$f]}" ] || { echo "STOPPED: $f on the server is $got, expected ${PRE[$f]}. Nothing was changed."; exit 2; }; done
[ ! -e "$B/models/SurveyStart.js" ] || { echo "STOPPED: models/SurveyStart.js already exists. Nothing was changed."; exit 2; }
for f in "${!NEW[@]}"; do got=$(sha256sum "$REL/src/$f" | cut -c1-12); [ "$got" = "${NEW[$f]}" ] || { echo "STOPPED: release copy of $f is $got, not the tested file. Nothing was changed."; exit 2; }; node --check "$REL/src/$f"; done
mkdir -p "$KEEP/controllers" "$KEEP/models" "$KEEP/services" "$KEEP/routes"; for f in "${!PRE[@]}"; do cp -p "$B/$f" "$KEEP/$f"; done
for f in "${!NEW[@]}"; do cp "$REL/src/$f" "$B/$f"; cmp -s "$REL/src/$f" "$B/$f" || { echo "COPY MISMATCH $f"; exit 3; }; done
echo "applied 5 replaced + 1 new file; previous copies in $KEEP"
