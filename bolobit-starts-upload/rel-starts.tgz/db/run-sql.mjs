#!/usr/bin/env node
/**
 * run-sql.mjs — run psql against the database a service's .env points at,
 * without printing or typing the password.
 *
 *   node /full/path/db/run-sql.mjs /home/ubuntu/backend/.env -f /full/path/db/preflight.sql
 *   node /full/path/db/run-sql.mjs /home/ubuntu/backend/.env -Atc "select 1"
 *
 * Everything after the .env path is passed to psql unchanged. psql always runs
 * with -X (ignore ~/.psqlrc) and ON_ERROR_STOP=1, and exits with psql's status.
 *
 * Reads DB_HOST / DB_PORT / DB_NAME / DB_USER / DB_PASSWORD (+ DB_SSL, DB_SSL_CA),
 * or DATABASE_URL when DB_NAME / DB_USER are absent. SSL: "require" by default,
 * "verify-full" when DB_SSL_CA is set, "disable" only when DB_SSL=false.
 * The password is handed to psql through PGPASSWORD and never printed. When the
 * .env file has none (secrets in Parameter Store, D-32), DB_PASSWORD from the
 * environment is used, which is where the secrets launcher puts it.
 * No dependencies: runs from any folder with any Node 18+.
 */

import fs from 'fs';
import path from 'path';
import { createRequire } from 'module';
import { spawnSync } from 'child_process';

const [envPath, ...psqlArgs] = process.argv.slice(2);

function fail(message, code = 2) {
  console.error(`run-sql: ${message}`);
  process.exit(code);
}

if (!envPath || psqlArgs.length === 0) {
  fail('usage: node run-sql.mjs /full/path/to/.env -f /full/path/file.sql   (or -c "SQL")');
}

let text;
try {
  text = fs.readFileSync(envPath, 'utf8');
} catch (err) {
  fail(`cannot read ${envPath} (${err.code || err.message})`);
}

/**
 * Values must be read exactly as the service reads them. So: use the service's
 * own dotenv (resolved from the .env's folder) when it is installed; otherwise
 * the same rules as dotenv 16 (copied from its lib/main.js) — notably an
 * unquoted value ends at the first "#".
 */
function parseEnv(source) {
  try {
    const req = createRequire(path.resolve(envPath));
    const dotenv = req(req.resolve('dotenv'));
    if (typeof dotenv.parse === 'function') return dotenv.parse(source);
  } catch { /* dotenv not installed next to this .env — use the built-in rules */ }
  const LINE = /(?:^|^)\s*(?:export\s+)?([\w.-]+)(?:\s*=\s*?|:\s+?)(\s*'(?:\\'|[^'])*'|\s*"(?:\\"|[^"])*"|\s*`(?:\\`|[^`])*`|[^#\r\n]+)?\s*(?:#.*)?(?:$|$)/mg;
  const lines = source.replace(/\r\n?/mg, '\n');
  const out = {};
  let match;
  while ((match = LINE.exec(lines)) != null) {
    let value = (match[2] || '').trim();
    const maybeQuote = value[0];
    value = value.replace(/^(['"`])([\s\S]*)\1$/mg, '$2');
    if (maybeQuote === '"') value = value.replace(/\\n/g, '\n').replace(/\\r/g, '\r');
    out[match[1]] = value;
  }
  return out;
}

const env = parseEnv(text);
const has = (k) => env[k] !== undefined && env[k] !== '';

// Start from the caller's environment minus any PG* settings, so a stray
// PGHOST / PGPASSWORD in the shell can never redirect or leak the run.
const child = Object.fromEntries(Object.entries(process.env).filter(([k]) => !k.startsWith('PG')));
let target;

if (has('DB_NAME') && has('DB_USER')) {
  child.PGHOST = env.DB_HOST || 'localhost';
  child.PGPORT = env.DB_PORT || '5432';
  child.PGDATABASE = env.DB_NAME;
  child.PGUSER = env.DB_USER;
  if (has('DB_PASSWORD')) child.PGPASSWORD = env.DB_PASSWORD;
  // Since D-32 the password lives in SSM Parameter Store, not the .env file: run
  // through the secrets launcher it arrives as DB_PASSWORD in the environment.
  //   node /home/ubuntu/ops/secrets/with-secrets.mjs backend -- node run-sql.mjs <.env> -f x.sql
  else if (process.env.DB_PASSWORD) child.PGPASSWORD = process.env.DB_PASSWORD;
  target = `host=${child.PGHOST} port=${child.PGPORT} db=${child.PGDATABASE} user=${child.PGUSER}`;
} else if (has('DATABASE_URL')) {
  // psql accepts a connection URI in place of a database name. An sslmode
  // inside the URL takes precedence over PGSSLMODE below.
  child.PGDATABASE = env.DATABASE_URL;
  let shown = 'DATABASE_URL';
  try {
    const u = new URL(env.DATABASE_URL);
    shown = `host=${u.hostname} port=${u.port || '5432'} db=${u.pathname.slice(1)} user=${decodeURIComponent(u.username)} (from DATABASE_URL)`;
  } catch { /* keep the generic label; never echo the raw URL (it may hold the password) */ }
  target = shown;
} else {
  fail(`${envPath} has neither DB_NAME + DB_USER nor DATABASE_URL`);
}

if (env.DB_SSL === 'false') {
  child.PGSSLMODE = 'disable';
} else if (has('DB_SSL_CA')) {
  child.PGSSLMODE = 'verify-full';
  child.PGSSLROOTCERT = env.DB_SSL_CA;
} else {
  child.PGSSLMODE = 'require';
}

console.error(`run-sql: ${target} sslmode=${child.PGSSLMODE}`);

const result = spawnSync('psql', ['-X', '-v', 'ON_ERROR_STOP=1', ...psqlArgs], { stdio: 'inherit', env: child });
if (result.error) {
  fail(result.error.code === 'ENOENT' ? 'psql is not installed on this machine' : result.error.message, 127);
}
process.exit(result.status ?? 1);
