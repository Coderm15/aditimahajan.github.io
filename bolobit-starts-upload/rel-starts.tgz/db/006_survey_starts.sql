-- 006 — Survey starts (D-54): makes completion and drop-off real numbers.
--
-- Until now a response was recorded only when it was submitted, so completion was
-- always 100% and drop-off always 0%. This table counts people who STARTED a survey
-- (answered its first question) and how far they got, anonymously:
--   survey_starts   one row per start: a random token the respondent's browser makes,
--                   the highest question position reached, and the response it became
--                   when submitted. No name, email, IP address or device is stored.
--
-- Nothing existing is changed. Old responses (before this table) have no start and
-- are left out of completion; the report says from when completion is measured.
--
-- One transaction, safe to run twice, lock_timeout 5 s. Stops with a clear message,
-- changing nothing, if 002 (surveys) is missing.

BEGIN;
SET LOCAL lock_timeout = '5s';

DO $$
BEGIN
  IF to_regclass('surveys') IS NULL OR to_regclass('survey_responses') IS NULL THEN
    RAISE EXCEPTION 'STOPPED: survey tables are missing. Run 002_surveys.sql first. Nothing was changed.';
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS survey_starts (
  survey_id      UUID NOT NULL REFERENCES surveys(id) ON DELETE CASCADE,
  start_token    UUID NOT NULL,
  last_position  SMALLINT NOT NULL DEFAULT 1 CHECK (last_position >= 1),
  response_id    UUID REFERENCES survey_responses(id) ON DELETE SET NULL,
  started_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (survey_id, start_token)
);

-- One submitted response belongs to at most one start.
CREATE UNIQUE INDEX IF NOT EXISTS survey_starts_response_uidx ON survey_starts (response_id) WHERE response_id IS NOT NULL;

COMMIT;
