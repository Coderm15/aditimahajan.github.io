/**
 * @fileoverview Public respondent path, no auth (Handover §16, Phase 1 Code spec §8.4).
 *
 * Guards: foreign question ids and duplicate answers rejected; every answer
 * validated against its own question; tenant fields never leave the server;
 * absent/draft/archived surveys give a byte-identical 404 and closed ones 410;
 * the 201 goes out before any post-processing (verification, R3c).
 */

import * as Survey from '../models/Survey.js';
import * as SurveyResponse from '../models/SurveyResponse.js';
import { pastDeadline, SUBMIT } from '../models/SurveyResponse.js';
import { validateAnswer, LIMITS, takesComment } from '../utils/surveyValidation.js';
import { responseMeta } from '../utils/requestMeta.js';
import * as SurveyStart from '../models/SurveyStart.js';
import { TOKEN_RE } from '../models/SurveyStart.js';

/**
 * D-54 start counting. One browser (survey + IP + browser fingerprint, held in memory
 * only, never stored) may open at most START_LIMIT new starts an hour, so nobody can
 * push a survey's completion down by flooding it. Progress on a known start is free.
 */
export const START_LIMIT = 5;
const START_WINDOW_MS = 60 * 60 * 1000;
const startsByKey = new Map(); // key -> { until, tokens:Set }
function allowStart(key, token) {
  const now = Date.now();
  if (startsByKey.size > 50_000) for (const [k, v] of startsByKey) if (v.until < now) startsByKey.delete(k);
  let e = startsByKey.get(key);
  if (!e || e.until < now) { e = { until: now + START_WINDOW_MS, tokens: new Set() }; startsByKey.set(key, e); }
  if (e.tokens.has(token)) return true;
  if (e.tokens.size >= START_LIMIT) return false;
  e.tokens.add(token);
  return true;
}
export function resetStartLimits() { startsByKey.clear(); }

const CODE_RE = /^[A-Z0-9]{4,8}$/;
const NOT_FOUND = { success: false, message: 'Survey not found' };
const CLOSED = { success: false, message: 'This survey is closed and no longer accepting responses' };

/** Post-submit work (verification in R3c). Never awaited by the request. */
let afterSubmit = () => {};
export function setAfterSubmit(fn) { afterSubmit = typeof fn === 'function' ? fn : () => {}; }

async function load(req, res) {
  const code = String(req.params.shortCode || '').toUpperCase();
  if (!CODE_RE.test(code)) { res.status(404).json(NOT_FOUND); return null; }
  const survey = await Survey.findByShortCode(code);
  if (!survey || survey.status === 'draft' || survey.status === 'archived') { res.status(404).json(NOT_FOUND); return null; }
  if (survey.status === 'closed' || pastDeadline(survey.deadline)) { res.status(410).json(CLOSED); return null; }
  return survey;
}

/** Only what a respondent needs: no business_id, created_by, counts, caps or flags. */
function publicView(s) {
  return {
    short_code: s.short_code,
    title: s.title,
    description: s.description,
    ask_name: s.anonymous === false,
    questions: s.questions.map((q) => ({
      id: q.id, position: q.position, text: q.text, type: q.type,
      options: q.options, required: q.required, allow_comment: takesComment(q),
    })),
  };
}

export async function getSurvey(req, res, next) {
  try {
    const survey = await load(req, res); if (!survey) return undefined;
    res.set('Cache-Control', 'no-store');
    return res.json({ success: true, data: { survey: publicView(survey) } });
  } catch (err) { return next(err); }
}

export async function submit(req, res, next) {
  try {
    const survey = await load(req, res); if (!survey) return undefined;
    const body = req.body || {};
    const raw = body.answers;
    if (!Array.isArray(raw) || raw.length > survey.questions.length) {
      return res.status(400).json({ success: false, message: 'Send your answers as a list' });
    }
    const byId = new Map(survey.questions.map((q) => [q.id, q]));
    const seen = new Set();
    const answers = [];
    for (const a of raw) {
      const q = byId.get(a?.question_id);
      if (!q) return res.status(400).json({ success: false, message: 'An answer refers to a question that is not in this survey' });
      if (seen.has(q.id)) return res.status(400).json({ success: false, message: 'Each question can be answered once' });
      seen.add(q.id);
      const v = validateAnswer(q, a);
      if (!v.valid) return res.status(400).json({ success: false, message: v.message });
      const empty = a.value === undefined || a.value === null || (typeof a.value === 'string' && a.value.trim() === '');
      if (!empty) answers.push({ question: q, value: typeof a.value === 'string' ? a.value.trim() : a.value, comment: typeof a.comment === 'string' && a.comment.trim() ? a.comment.trim() : null });
    }
    for (const q of survey.questions) {
      if (q.required && !seen.has(q.id)) return res.status(400).json({ success: false, message: `Please answer: "${q.text}"` });
    }

    let label = null;
    if (survey.anonymous === false && body.respondent_label !== undefined && body.respondent_label !== null) {
      if (typeof body.respondent_label !== 'string' || body.respondent_label.length > LIMITS.respondentLabel) {
        return res.status(400).json({ success: false, message: `Keep your name under ${LIMITS.respondentLabel} characters` });
      }
      label = body.respondent_label.trim() || null;
    }

    const started = Date.parse(body.started_at);
    const startedAt = Number.isFinite(started) && started <= Date.now() ? new Date(started) : null;
    const duration = startedAt ? Math.min(Math.round((Date.now() - started) / 1000), 86_400) : null;
    const lastPosition = answers.reduce((m, a) => Math.max(m, a.question.position), 0);

    const startToken = typeof body.start_token === 'string' && TOKEN_RE.test(body.start_token) ? body.start_token.toLowerCase() : null;
    const out = await SurveyResponse.submit({
      surveyId: survey.id,
      userId: null,
      meta: responseMeta(req, survey.id, body.channel),
      respondentLabel: label,
      answers,
      lastPosition,
      completed: true,
      durationSeconds: duration,
      startedAt,
      startToken,
    });

    switch (out.result) {
      case SUBMIT.OK:
        res.status(201).json({ success: true, data: { received: true } });
        setImmediate(() => { try { afterSubmit({ surveyId: survey.id, responseId: out.responseId }); } catch { /* never reaches the respondent */ } });
        return undefined;
      case SUBMIT.NOT_FOUND: return res.status(404).json(NOT_FOUND);
      case SUBMIT.NOT_ACTIVE:
      case SUBMIT.PAST_DEADLINE: return res.status(410).json(CLOSED);
      case SUBMIT.CAP_REACHED: return res.status(409).json({ success: false, message: 'This survey has reached its response limit' });
      case SUBMIT.ALREADY_TAKEN: return res.status(409).json({ success: false, message: 'You have already answered this survey' });
      default: throw new Error(`unexpected submit result ${out.result}`);
    }
  } catch (err) { return next(err); }
}

/**
 * POST /public/surveys/:code/starts  { token, position }  → 204
 * The respondent page calls this when someone answers their first question, and again
 * as they get further. Always 204 for a valid body (a refused start is not revealed).
 */
export async function recordStart(req, res, next) {
  try {
    const survey = await load(req, res); if (!survey) return undefined;
    const body = req.body || {};
    const maxPos = survey.questions.reduce((m, q) => Math.max(m, q.position), 0);
    const position = Number(body.position);
    if (typeof body.token !== 'string' || !TOKEN_RE.test(body.token) || !Number.isInteger(position) || position < 1 || position > maxPos) {
      return res.status(400).json({ success: false, message: 'Invalid start' });
    }
    const token = body.token.toLowerCase();
    if (allowStart(responseMeta(req, survey.id).respondent_key, token)) await SurveyStart.record(survey.id, token, position);
    return res.status(204).end();
  } catch (err) { return next(err); }
}
