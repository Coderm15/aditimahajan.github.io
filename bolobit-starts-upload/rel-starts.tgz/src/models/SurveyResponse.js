/**
 * @fileoverview Survey responses (Phase 1 Code spec §7.2).
 *
 * submit() order is mandatory: lock the survey row FIRST, then status /
 * deadline / cap / one-per-user checks, then inserts, then COMMIT. Without the
 * lock, two concurrent submits both read count = max-1 and breach the cap.
 */

import pool from '../config/database.js';
import { linkResponse } from './SurveyStart.js';

export const SUBMIT = Object.freeze({
  OK: 'OK', NOT_FOUND: 'NOT_FOUND', NOT_ACTIVE: 'NOT_ACTIVE', CAP_REACHED: 'CAP_REACHED',
  ALREADY_TAKEN: 'ALREADY_TAKEN', PAST_DEADLINE: 'PAST_DEADLINE',
});

/** Map a validated answer value onto its column for the question type. */
function columnsFor(type, value) {
  return {
    choice_selected: type === 'mc' ? value : null,
    rating_value: type === 'rating' ? value : null,
    nps_value: type === 'nps' ? value : null,
    text_response: type === 'open' ? value : null,
  };
}

/** True when the deadline (a DATE) has passed: open until 23:59:59.999 UTC that day. */
export function pastDeadline(deadline, now = new Date()) {
  if (!deadline) return false;
  const d = deadline instanceof Date ? deadline.toISOString().slice(0, 10) : String(deadline).slice(0, 10);
  return now.getTime() > Date.parse(`${d}T23:59:59.999Z`);
}

/**
 * @param {{surveyId, userId?, meta, respondentLabel?, answers: Array<{question, value, comment?}>,
 *          lastPosition, completed, durationSeconds?, startedAt?, startToken?}} input
 * @returns {Promise<{result: string, responseId?: string}>}
 */
export async function submit({ surveyId, userId = null, meta, respondentLabel = null, answers, lastPosition, completed, durationSeconds = null, startedAt = null, startToken = null }) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const s = await client.query(
      // deadline as text: see findByShortCode — never let pg turn the DATE into local midnight
      "SELECT id, status, one_per_user, max_responses, to_char(deadline, 'YYYY-MM-DD') AS deadline FROM surveys WHERE id = $1 FOR UPDATE",
      [surveyId],
    );
    const survey = s.rows[0];
    if (!survey) { await client.query('ROLLBACK'); return { result: SUBMIT.NOT_FOUND }; }
    if (survey.status !== 'active') { await client.query('ROLLBACK'); return { result: SUBMIT.NOT_ACTIVE }; }
    if (pastDeadline(survey.deadline)) { await client.query('ROLLBACK'); return { result: SUBMIT.PAST_DEADLINE }; }
    if (survey.max_responses) {
      const c = await client.query('SELECT count(*)::int AS n FROM survey_responses WHERE survey_id = $1', [surveyId]);
      if (c.rows[0].n >= survey.max_responses) { await client.query('ROLLBACK'); return { result: SUBMIT.CAP_REACHED }; }
    }
    if (survey.one_per_user) {
      const dup = userId
        ? await client.query('SELECT 1 FROM survey_responses WHERE survey_id = $1 AND user_id = $2 LIMIT 1', [surveyId, userId])
        : await client.query('SELECT 1 FROM survey_responses WHERE survey_id = $1 AND respondent_key = $2 LIMIT 1', [surveyId, meta.respondent_key]);
      if (dup.rows[0]) { await client.query('ROLLBACK'); return { result: SUBMIT.ALREADY_TAKEN }; }
    }

    const r = await client.query(
      `INSERT INTO survey_responses (survey_id, user_id, respondent_key, respondent_label, channel, device_type, country_code,
                                     started_at, submitted_at, duration_seconds, completed, last_question_position)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW(), $9, $10, $11)
       RETURNING id`,
      [surveyId, userId, meta.respondent_key, respondentLabel, meta.channel, meta.device_type, meta.country_code,
        startedAt, durationSeconds, completed, lastPosition],
    );
    const responseId = r.rows[0].id;
    for (const a of answers) {
      const cols = columnsFor(a.question.type, a.value);
      await client.query(
        `INSERT INTO survey_answers (response_id, question_id, choice_selected, rating_value, nps_value, text_response, comment)
         VALUES ($1, $2, $3, $4, $5, $6, $7)
         ON CONFLICT (response_id, question_id) DO NOTHING`,
        [responseId, a.question.id, cols.choice_selected, cols.rating_value, cols.nps_value, cols.text_response, a.comment ?? null],
      );
    }
    // D-54: the start this response came from now counts as submitted.
    if (startToken) await linkResponse(client, surveyId, startToken, responseId, lastPosition);
    if (userId) {
      await client.query(
        `UPDATE survey_invites SET responded_at = NOW()
          WHERE survey_id = $1 AND responded_at IS NULL
            AND lower(email) = (SELECT lower(email) FROM users WHERE id = $2)`,
        [surveyId, userId],
      );
    }
    await client.query('COMMIT');
    return { result: SUBMIT.OK, responseId };
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    client.release();
  }
}

/** Store verification output for one answer (R3c). */
export async function setPillarSignal(answerId, signal) {
  await pool.query(
    'UPDATE survey_answers SET pillar_signal = $2::jsonb, verified_at = CASE WHEN $2::jsonb IS NULL THEN NULL ELSE NOW() END WHERE id = $1',
    [answerId, signal === null ? null : JSON.stringify(signal)],
  );
}
