/**
 * @fileoverview Rows for the live report, and the stored eligibility verdict.
 * Every query is scoped to the business that owns the survey (Master Spec §16.1).
 */

import pool from '../config/database.js';
import { summary as startSummary } from './SurveyStart.js';

/** Survey + questions + responses + answers for one survey of one business, or null. */
export async function loadRows(surveyId, businessId) {
  const s = await pool.query(
    `SELECT id, title, business_objective, status, mode, pillars_by, anonymous, audience_size, published_at, closed_at,
            iq_eligible, iq_rubric_version, iq_verdict_reason, iq_evaluated_at
       FROM surveys WHERE id = $1 AND business_id = $2`,
    [surveyId, businessId],
  );
  if (!s.rows[0]) return null;
  const [q, r, a, starts] = await Promise.all([
    pool.query(
      `SELECT q.id, q.position, q.text, q.type, q.options, q.pillars
         FROM survey_questions q JOIN surveys s ON s.id = q.survey_id
        WHERE q.survey_id = $1 AND s.business_id = $2 ORDER BY q.position`,
      [surveyId, businessId],
    ),
    pool.query(
      `SELECT r.id, r.respondent_label, r.completed, r.last_question_position, r.submitted_at
         FROM survey_responses r JOIN surveys s ON s.id = r.survey_id
        WHERE r.survey_id = $1 AND s.business_id = $2 ORDER BY r.submitted_at NULLS LAST, r.created_at`,
      [surveyId, businessId],
    ),
    pool.query(
      `SELECT a.response_id, a.question_id, a.choice_selected, a.rating_value, a.nps_value, a.text_response,
              a.pillar_signal, a.verified_at, a.verification_attempts
         FROM survey_answers a
         JOIN survey_responses r ON r.id = a.response_id
         JOIN surveys s ON s.id = r.survey_id
        WHERE r.survey_id = $1 AND s.business_id = $2`,
      [surveyId, businessId],
    ),
    startSummary(surveyId, businessId),
  ]);
  return { survey: s.rows[0], questions: q.rows, responses: r.rows, answers: a.rows, starts };
}

/**
 * Pin the verdict once (rubric is versioned; a verdict is never silently re-decided).
 * Returns true when this call stored it.
 */
export async function storeVerdict(surveyId, businessId, { eligible, rubricVersion, criteria }) {
  const { rowCount } = await pool.query(
    `UPDATE surveys
        SET iq_eligible = $3, iq_rubric_version = $4, iq_verdict_reason = $5::jsonb, iq_evaluated_at = NOW()
      WHERE id = $1 AND business_id = $2 AND status IN ('closed', 'archived') AND iq_evaluated_at IS NULL`,
    [surveyId, businessId, eligible, rubricVersion, JSON.stringify(criteria)],
  );
  return rowCount === 1;
}
