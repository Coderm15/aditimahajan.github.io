/**
 * @fileoverview Survey starts (D-54, migration 006): anonymous counts of people who
 * started a survey and how far they got, so completion and drop-off are measured.
 * Stores a random browser token per start, never a name, email, IP or device.
 */

import pool from '../config/database.js';

export const TOKEN_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

/**
 * Record a start, or move it forward. Never moves backwards and never changes a
 * start that already became a response.
 * @returns {Promise<boolean>} true when a row was written
 */
export async function record(surveyId, token, position, db = pool) {
  const { rowCount } = await db.query(
    `INSERT INTO survey_starts (survey_id, start_token, last_position)
     VALUES ($1, $2, $3)
     ON CONFLICT (survey_id, start_token) DO UPDATE
        SET last_position = GREATEST(survey_starts.last_position, EXCLUDED.last_position), updated_at = NOW()
      WHERE survey_starts.response_id IS NULL`,
    [surveyId, token, position],
  );
  return rowCount === 1;
}

/**
 * Link a submitted response to its start (inside the submit transaction). A start the
 * browser never managed to send is created here, so a submitted response always counts.
 */
export async function linkResponse(client, surveyId, token, responseId, lastPosition) {
  await client.query(
    `INSERT INTO survey_starts (survey_id, start_token, last_position, response_id)
     VALUES ($1, $2, GREATEST($3::int, 1), $4)
     ON CONFLICT (survey_id, start_token) DO UPDATE
        SET response_id = EXCLUDED.response_id,
            last_position = GREATEST(survey_starts.last_position, EXCLUDED.last_position),
            updated_at = NOW()
      WHERE survey_starts.response_id IS NULL`,
    [surveyId, token, lastPosition, responseId],
  );
}

/**
 * Aggregate for one survey (scoped to its business): how many started, how many of
 * those submitted, where the others stopped, and when counting began.
 * @returns {Promise<{started:number, submitted:number, stoppedAt:Object<number,number>, since:string|null}>}
 */
export async function summary(surveyId, businessId) {
  const { rows } = await pool.query(
    `SELECT st.last_position, (st.response_id IS NOT NULL) AS submitted, count(*)::int AS n, min(st.started_at) AS since
       FROM survey_starts st JOIN surveys s ON s.id = st.survey_id
      WHERE st.survey_id = $1 AND s.business_id = $2
      GROUP BY st.last_position, (st.response_id IS NOT NULL)`,
    [surveyId, businessId],
  );
  let started = 0; let submitted = 0; let since = null; const stoppedAt = {};
  for (const r of rows) {
    started += r.n;
    if (r.submitted) submitted += r.n;
    else stoppedAt[r.last_position] = (stoppedAt[r.last_position] || 0) + r.n;
    if (r.since && (!since || new Date(r.since) < new Date(since))) since = new Date(r.since).toISOString();
  }
  return { started, submitted, stoppedAt, since };
}
