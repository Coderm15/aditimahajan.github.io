/**
 * @fileoverview /api/v1/public — respondent path, NO auth.
 */

import { Router } from 'express';
import { getSurvey, submit, setAfterSubmit, recordStart } from '../controllers/publicSurveyController.js';
import { verifyResponseLater } from '../services/verification.js';
import { noStore, safeErrors } from '../utils/routerGuard.js';

// R3c: check each answer against its question's pillars after the respondent has their reply.
setAfterSubmit(verifyResponseLater);

const router = Router();
router.use(noStore);
router.get('/surveys/:shortCode', getSurvey);
router.post('/surveys/:shortCode/responses', submit);
router.post('/surveys/:shortCode/starts', recordStart);

router.use(safeErrors);

export default router;
