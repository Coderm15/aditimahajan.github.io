// S8 read-only check against live data: SELECT only, prints aggregates (no titles, names or answers).
import pool from '/home/ubuntu/backend/src/config/database.js';
import { computeNps, completionPct } from '/home/ubuntu/backend/src/engine/scoring.js';
import { ANONYMITY_FLOOR } from '/home/ubuntu/backend/src/services/surveyReport.js';
/**
 * @fileoverview Rows for the S8 Results overview (D-54). Every query is scoped to one
 * business. Drafts and archived surveys are left out: drafts have no results, and
 * archived surveys (where test surveys go) are out of the business's view.
 *
 * "In the period" means: responses submitted, and starts begun, on or after `since`.
 * A survey belongs to the period when it was collecting at any time in it
 * (still live, or closed on or after `since`). `since = null` is all time.
 */


/** One row per live or closed survey in the period, with that period's raw counts. */
async function surveyRows(businessId, since) {
  const { rows } = await pool.query(
    `SELECT s.id, s.title, s.status, s.mode, s.anonymous, s.published_at, s.closed_at,
            (SELECT count(*)::int FROM survey_responses r
              WHERE r.survey_id = s.id AND r.submitted_at IS NOT NULL
                AND ($2::timestamptz IS NULL OR r.submitted_at >= $2::timestamptz)) AS responses,
            (SELECT count(*)::int FROM survey_responses r
              WHERE r.survey_id = s.id AND r.submitted_at IS NOT NULL) AS responses_all_time,
            (SELECT count(*)::int FROM survey_starts st
              WHERE st.survey_id = s.id AND ($2::timestamptz IS NULL OR st.started_at >= $2::timestamptz)) AS started,
            (SELECT count(*)::int FROM survey_starts st
              WHERE st.survey_id = s.id AND st.response_id IS NOT NULL
                AND ($2::timestamptz IS NULL OR st.started_at >= $2::timestamptz)) AS finished,
            (SELECT COALESCE(json_object_agg(d.v, d.n), '{}'::json) FROM (
               SELECT a.nps_value AS v, count(*)::int AS n
                 FROM survey_answers a JOIN survey_responses r ON r.id = a.response_id
                WHERE r.survey_id = s.id AND a.nps_value IS NOT NULL AND r.submitted_at IS NOT NULL
                  AND ($2::timestamptz IS NULL OR r.submitted_at >= $2::timestamptz)
                GROUP BY a.nps_value) d) AS nps_distribution
       FROM surveys s
      WHERE s.business_id = $1 AND s.status IN ('active', 'closed')
        AND ($2::timestamptz IS NULL OR s.status = 'active' OR s.closed_at IS NULL OR s.closed_at >= $2::timestamptz)
      ORDER BY (s.status = 'active') DESC, s.published_at DESC NULLS LAST, s.created_at DESC`,
    [businessId, since],
  );
  return rows;
}

/** Median seconds per person (finished responses with a recorded time) in the period. */
async function medianTime(businessId, since) {
  const { rows } = await pool.query(
    `SELECT percentile_cont(0.5) WITHIN GROUP (ORDER BY r.duration_seconds) AS median, count(*)::int AS n
       FROM survey_responses r JOIN surveys s ON s.id = r.survey_id
      WHERE s.business_id = $1 AND s.status IN ('active', 'closed')
        AND r.completed AND r.duration_seconds IS NOT NULL AND r.submitted_at IS NOT NULL
        AND ($2::timestamptz IS NULL OR r.submitted_at >= $2::timestamptz)`,
    [businessId, since],
  );
  const { median, n } = rows[0];
  return { seconds: median === null ? null : Math.round(Number(median)), timed: n };
}

/** Responses submitted in [from, to): the period before, for the change figure. */
async function responsesBetween(businessId, from, to) {
  const { rows } = await pool.query(
    `SELECT count(*)::int AS n
       FROM survey_responses r JOIN surveys s ON s.id = r.survey_id
      WHERE s.business_id = $1 AND s.status IN ('active', 'closed')
        AND r.submitted_at >= $2::timestamptz AND r.submitted_at < $3::timestamptz`,
    [businessId, from, to],
  );
  return rows[0].n;
}

/** Surveys collecting right now. */
async function activeCount(businessId) {
  const { rows } = await pool.query(
    `SELECT count(*)::int AS n FROM surveys WHERE business_id = $1 AND status = 'active'`,
    [businessId],
  );
  return rows[0].n;
}



const PERIODS = Object.freeze({ 30: 30, 90: 90, 365: 365, all: null });
const DEFAULT_PERIOD = '90';
const DAY_MS = 86_400_000;

/** `since` for a period key, or null for all time. Throws on an unknown key. */
function periodStart(period, now = new Date()) {
  if (!Object.prototype.hasOwnProperty.call(PERIODS, period)) throw new RangeError('Unknown period');
  const days = PERIODS[period];
  return days === null ? null : new Date(now.getTime() - days * DAY_MS);
}

const countOf = (dist) => Object.values(dist || {}).reduce((n, c) => n + (Number(c) || 0), 0);

function addInto(target, dist) {
  for (const [k, c] of Object.entries(dist || {})) target[k] = (target[k] || 0) + (Number(c) || 0);
}

/**
 * @param {{rows:Array, median:{seconds:number|null,timed:number}, previous:number|null,
 *          active:number, period:string, since:Date|null}} input
 *   rows      from SurveyResults.surveyRows
 *   previous  responses in the period before (null for all time)
 */
function buildOverview({ rows, median, previous, active, period, since }) {
  const pooledNps = {};
  let started = 0;
  let finished = 0;
  let responses = 0;

  const surveys = rows.map((r) => {
    const protectedNps = r.anonymous && r.responses_all_time < ANONYMITY_FLOOR;
    const npsAnswers = protectedNps ? 0 : countOf(r.nps_distribution);
    if (!protectedNps) addInto(pooledNps, r.nps_distribution);
    started += r.started;
    finished += r.finished;
    responses += r.responses;
    return {
      id: r.id,
      title: r.title,
      status: r.status,
      mode: r.mode,
      responses: r.responses,
      completion: r.started > 0 ? { pct: completionPct(r.finished, r.started), finished: r.finished, started: r.started } : null,
      nps: npsAnswers > 0 ? { score: computeNps(r.nps_distribution), answers: npsAnswers } : null,
      npsHidden: protectedNps && countOf(r.nps_distribution) > 0,
    };
  });

  const npsAnswers = countOf(pooledNps);
  const change = previous && previous > 0 ? Math.round((100 * (responses - previous)) / previous) : null;

  return {
    period,
    since: since ? since.toISOString() : null,
    tiles: {
      responses: { total: responses, previous: previous ?? null, changePct: change },
      completion: started > 0 ? { pct: completionPct(finished, started), finished, started } : null,
      nps: npsAnswers > 0 ? { score: computeNps(pooledNps), answers: npsAnswers } : null,
      active,
      medianTime: median.seconds === null ? null : { seconds: median.seconds, timed: median.timed },
    },
    surveys,
  };
}

const out = [];
let pass = 0, fail = 0;
const ok = (c, m) => { c ? pass++ : fail++; out.push(`${c ? 'PASS' : 'FAIL'} ${m}`); };
const { rows: biz } = await pool.query(`SELECT business_id, count(*)::int AS n FROM surveys GROUP BY business_id ORDER BY n DESC`);
const legacy = (await pool.query(`SELECT
  (SELECT count(*)::int FROM surveys WHERE status='closed' AND closed_at IS NULL) AS closed_no_date,
  (SELECT count(*)::int FROM survey_responses WHERE submitted_at IS NULL) AS unsubmitted,
  (SELECT count(*)::int FROM survey_responses WHERE submitted_at IS NOT NULL AND NOT completed) AS submitted_not_completed,
  (SELECT count(*)::int FROM survey_responses WHERE duration_seconds IS NULL) AS untimed,
  (SELECT count(*)::int FROM surveys) AS surveys, (SELECT count(*)::int FROM survey_responses) AS responses,
  (SELECT count(*)::int FROM survey_starts) AS starts`)).rows[0];
out.push(`live data: ${JSON.stringify(legacy)}`);
let i = 0;
const now = new Date();
for (const b of biz) {
  i += 1;
  for (const period of ['30', '90', 'all']) {
    const since = periodStart(period, now);
    const before = since ? new Date(since.getTime() - (now.getTime() - since.getTime())) : null;
    const t0 = Date.now();
    const [rows, median, previous, active] = await Promise.all([surveyRows(b.business_id, since), medianTime(b.business_id, since),
      since ? responsesBetween(b.business_id, before, since) : null, activeCount(b.business_id)]);
    const ov = buildOverview({ rows, median, previous, active, period, since });
    const ms = Date.now() - t0;
    // independent figures, written differently
    const ind = (await pool.query(`SELECT
        count(DISTINCT r.id)::int AS responses,
        count(a.id) FILTER (WHERE a.nps_value IS NOT NULL AND NOT (s.anonymous AND (SELECT count(*) FROM survey_responses x WHERE x.survey_id=s.id AND x.submitted_at IS NOT NULL) < 5))::int AS nps_n,
        count(a.id) FILTER (WHERE a.nps_value >= 9 AND NOT (s.anonymous AND (SELECT count(*) FROM survey_responses x WHERE x.survey_id=s.id AND x.submitted_at IS NOT NULL) < 5))::int AS pro,
        count(a.id) FILTER (WHERE a.nps_value <= 6 AND NOT (s.anonymous AND (SELECT count(*) FROM survey_responses x WHERE x.survey_id=s.id AND x.submitted_at IS NOT NULL) < 5))::int AS det
      FROM surveys s JOIN survey_responses r ON r.survey_id = s.id AND r.submitted_at IS NOT NULL AND ($2::timestamptz IS NULL OR r.submitted_at >= $2)
      LEFT JOIN survey_answers a ON a.response_id = r.id
      WHERE s.business_id = $1 AND s.status IN ('active','closed')`, [b.business_id, since])).rows[0];
    const st = (await pool.query(`SELECT count(*)::int AS started, count(response_id)::int AS finished FROM survey_starts st JOIN surveys s ON s.id = st.survey_id
      WHERE s.business_id = $1 AND s.status IN ('active','closed') AND ($2::timestamptz IS NULL OR st.started_at >= $2)`, [b.business_id, since])).rows[0];
    const npsInd = ind.nps_n ? Math.round(100 * (ind.pro - ind.det) / ind.nps_n) : null;
    const tag = `business ${i} · ${period}`;
    ok(ov.tiles.responses.total === ind.responses, `${tag}: responses ${ov.tiles.responses.total} = independent ${ind.responses}`);
    ok((ov.tiles.nps?.answers ?? 0) === ind.nps_n && (ov.tiles.nps?.score ?? null) === npsInd, `${tag}: NPS ${ov.tiles.nps?.score ?? '—'} on ${ov.tiles.nps?.answers ?? 0} = independent ${npsInd ?? '—'} on ${ind.nps_n}`);
    ok((ov.tiles.completion?.started ?? 0) === st.started && (ov.tiles.completion?.finished ?? 0) === st.finished, `${tag}: completion ${ov.tiles.completion ? `${ov.tiles.completion.finished}/${ov.tiles.completion.started}` : 'not measured'} = independent ${st.finished}/${st.started}`);
    ok(ms < 1500, `${tag}: answered in ${ms} ms · ${ov.surveys.length} surveys listed · active ${ov.tiles.active} · median ${ov.tiles.medianTime ? ov.tiles.medianTime.seconds + 's' : '—'} · change ${ov.tiles.responses.changePct ?? '—'}`);
  }
}
await pool.end();
console.log(out.join('\n'));
console.log(`\n${pass} passed, ${fail} failed`);
