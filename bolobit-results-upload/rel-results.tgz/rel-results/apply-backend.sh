#!/bin/bash
# S8 Results (D-54): 4 replaced backend files + 3 new. Checks every replaced server file is
# still the last released version, and that the new files do not exist yet, before touching anything.
set -euo pipefail
REL=$(cd "$(dirname "$0")" && pwd); B=/home/ubuntu/backend/src; KEEP=/home/ubuntu/backend/_replaced-20261126-results
declare -A PRE=( [controllers/surveyReportController.js]=b39bd15f6ce9 [models/SurveyReport.js]=51c1cd649011 [routes/surveys.js]=cd6eb02245fc [services/surveyReport.js]=a1211b7196d9 )
declare -A NEW=( [controllers/surveyReportController.js]=bf0b9fec0b5a [models/SurveyReport.js]=c3640fbbe31c [routes/surveys.js]=0a3da13f3ee8 [services/surveyReport.js]=436ab2eec510 [controllers/surveyResultsController.js]=98c505dc8f9e [models/SurveyResults.js]=5fb932c19426 [services/resultsOverview.js]=2bffb1d91659 )
for f in "${!PRE[@]}"; do got=$(sha256sum "$B/$f" | cut -c1-12); [ "$got" = "${PRE[$f]}" ] || { echo "STOPPED: $f on the server is $got, expected ${PRE[$f]}. Nothing was changed."; exit 2; }; done
for f in controllers/surveyResultsController.js models/SurveyResults.js services/resultsOverview.js; do [ ! -e "$B/$f" ] || { echo "STOPPED: $f already exists. Nothing was changed."; exit 2; }; done
for f in "${!NEW[@]}"; do got=$(sha256sum "$REL/src/$f" | cut -c1-12); [ "$got" = "${NEW[$f]}" ] || { echo "STOPPED: release copy of $f is $got, not the tested file. Nothing was changed."; exit 2; }; node --check "$REL/src/$f"; done
if [ "${1:-}" = "--check-only" ]; then echo "CHECK-OK: server files are the last released versions; release copies are the tested files"; exit 0; fi
mkdir -p "$KEEP/controllers" "$KEEP/models" "$KEEP/services" "$KEEP/routes"; for f in "${!PRE[@]}"; do cp -p "$B/$f" "$KEEP/$f"; done
for f in "${!NEW[@]}"; do cp "$REL/src/$f" "$B/$f"; cmp -s "$REL/src/$f" "$B/$f" || { echo "COPY MISMATCH $f"; exit 3; }; done
echo "applied 4 replaced + 3 new files; previous copies in $KEEP"
