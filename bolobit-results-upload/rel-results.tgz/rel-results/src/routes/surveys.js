/**
 * @fileoverview /api/v1/surveys — business survey CRUD + lifecycle.
 * Static segments are declared BEFORE /:id, or Express would treat them as ids.
 */

import { Router } from 'express';
import { authMiddleware } from '../middleware/jwtAuth.js';
import { requireBusinessUser } from '../middleware/roleMiddleware.js';
import * as c from '../controllers/surveyCrudController.js';
import { getReport } from '../controllers/surveyReportController.js';
import { getResults } from '../controllers/surveyResultsController.js';
import * as drafts from '../controllers/surveyDraftController.js';
import { noStore, safeErrors } from '../utils/routerGuard.js';

const router = Router();
router.use(noStore);
router.use(authMiddleware, requireBusinessUser);

router.get('/', c.list);
router.post('/', c.create);
router.get('/counts', c.counts);
router.get('/results', getResults);
router.post('/bulk', c.bulk);
router.post('/ai-drafts', drafts.create);
router.get('/ai-drafts/:draftId', drafts.get);

router.get('/:id', c.get);
router.get('/:id/report', getReport);
router.patch('/:id/audience', c.updateAudience);
router.patch('/:id', c.updateSetup);
router.delete('/:id', c.remove);
router.put('/:id/questions', c.replaceQuestions);
router.put('/:id/distribution', c.updateDistribution);
router.post('/:id/publish', c.publish);
router.patch('/:id/status', c.setStatus);
router.post('/:id/duplicate', c.duplicate);
router.put('/:id/bookmark', c.bookmark);

router.use(safeErrors);

export default router;
