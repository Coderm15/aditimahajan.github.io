/**
 * @fileoverview The live survey report (Master Spec §8–§11, Handover Appendix A).
 *
 * Pure: rows in, report out, no DB or network. Every number comes from the
 * pinned engine in ../engine (never re-implemented here). This file only
 * groups stored rows into the shapes the engine takes:
 *
 *   dual view   per question: verified[p] / delivered[p] / reclassified[p], from
 *               each answer's pillar_signal. Reclassified ("actual") signal goes
 *               to the generic view only, through dualView's own separate path.
 *   cohorts     each COMPLETED respondent, from VERIFIED answers only (Appendix A):
 *               a pillar with no verified answer is left unknown, never guessed.
 *               Several verified answers on one pillar: the riskiest level wins
 *               (BB-DEC-001, D-24).
 *   privacy     a base under 15 with fewer than 5 responses, or an anonymous survey
 *               with fewer than 5, is withheld: the usual report without the analysis
 *               (D-45) — a named survey keeps its answers as counts, an anonymous one
 *               shows none. Anonymous cohorts under
 *               5 people are hidden (applyAnonymityFloor). The close step builds with
 *               { withhold: false } so the verdict uses the real figures.
 *   empty       no responses at all: no report is built (D-40). The page gets
 *               { empty: true } and the survey, nothing else. The close step
 *               ({ withhold: false }) still records the verdict.
 *   gate        the current rubric (v2: responses from a third of the audience,
 *               which is at least 15). `responses` means every response collected,
 *               as the engine defines it. Criterion 5 (an AI judgment) is only ever
 *               decided when the survey closes; before that the gate is provisional.
 */

import { readFileSync } from 'node:fs';
import { intuitiveAnalysis } from './intuition.js';
import {
  computeNps, completionPct, uniformityPct, ratingAverage, dropOffFunnel, minNGate, pillarScoreFlat,
  dualView, distinctPillarsDelivered, coverageMode, cohortSummary, evaluateGate, CURRENT_RUBRIC, requiredResponses, MIN_AUDIENCE,
} from '../engine/index.js';

export const REPORT_VERSION = 1;
/** Distribution base below this is flagged; with fewer than MIN_ANALYSED responses on top, the analysis is withheld. */
export const MIN_BASE = MIN_AUDIENCE;
export const MIN_ANALYSED = 5;
/** Anonymous surveys never show a group of people smaller than this (industry anonymity threshold). */
export const ANONYMITY_FLOOR = 5;
/** Below this many responses the report is a low base: counts lead, percentages follow. */
export const LOW_RESPONSES = 30;
const PIN = JSON.parse(readFileSync(new URL('../engine/ENGINE_PIN.json', import.meta.url), 'utf8'));
export const ENGINE = Object.freeze({ repo: PIN.repo, commit: PIN.commit });
export const PILLARS = Object.freeze(['sentiment', 'behaviour', 'intent']);
/** Riskiest first: when one respondent's verified answers disagree, the first level found here wins. */
export const RISK_ORDER = Object.freeze({
  sentiment: Object.freeze(['negative', 'neutral', 'positive']),
  behaviour: Object.freeze(['disengaged', 'neutral', 'engaged']),
  intent: Object.freeze(['at_risk', 'wavering', 'committed']),
});
const OPEN_TEXT_SAMPLE = 10;

/**
 * Anonymity floor for the cohorts of an anonymous survey (count, share and members
 * hidden together). A cohort of 1–4 people is hidden. Hidden cohorts must not be
 * recoverable by subtracting the visible counts from the total, so more are hidden
 * (smallest non-empty first) until at least two are hidden and together they hold
 * at least `floor` people. When that is impossible (fewer than `floor` people
 * finished), every cohort is hidden. Empty cohorts otherwise stay visible.
 * @returns {{cohorts:Array, hidden:string[]}}
 */
export function applyAnonymityFloor(cohorts, floor = ANONYMITY_FLOOR) {
  const nonEmpty = cohorts.filter((c) => c.count > 0);
  const people = nonEmpty.reduce((n, c) => n + c.count, 0);
  let hidden = nonEmpty.filter((c) => c.count < floor);
  if (hidden.length && people < floor) {
    hidden = cohorts;
  } else if (hidden.length) {
    const rest = nonEmpty.filter((c) => c.count >= floor).sort((a, b) => a.count - b.count);
    const sum = () => hidden.reduce((n, c) => n + c.count, 0);
    while ((hidden.length < 2 || sum() < floor) && rest.length) hidden.push(rest.shift());
    if (hidden.length < 2 || sum() < floor) hidden = cohorts;
  }
  const keys = hidden.map((c) => c.key);
  return {
    hidden: keys,
    cohorts: cohorts.map((c) => (keys.includes(c.key) ? { ...c, count: null, pct: null, members: [], hidden: true } : c)),
  };
}

/** IANA time zone the business sees dates in, or UTC when absent or unknown. */
export function safeTimeZone(tz) {
  if (typeof tz !== 'string' || !tz || tz.length > 64) return 'UTC';
  try { new Intl.DateTimeFormat('en-US', { timeZone: tz }); return tz; } catch { return 'UTC'; }
}
const dayIn = (iso, tz) => new Date(iso).toLocaleDateString('en-CA', { timeZone: tz }); // YYYY-MM-DD
const addDays = (day, n) => new Date(Date.parse(`${day}T00:00:00Z`) + n * 86_400_000).toISOString().slice(0, 10);
const daysBetween = (a, b) => Math.round((Date.parse(`${b}T00:00:00Z`) - Date.parse(`${a}T00:00:00Z`)) / 86_400_000);
export const TIMELINE_DAILY_MAX = 62;

/**
 * S8 response timeline (D-54): submitted responses per day in the business's time zone,
 * from the first response to today (live) or to the close (closed). Spans longer than
 * TIMELINE_DAILY_MAX days are counted per 7-day step from the first day, so the chart
 * stays readable. Days with no responses are kept as zeros.
 */
export function responseTimeline(responses, { tz = 'UTC', end = null } = {}) {
  const days = responses.filter((r) => r.submitted_at && Number.isFinite(new Date(r.submitted_at).getTime()))
    .map((r) => dayIn(r.submitted_at, tz)).sort();
  if (!days.length) return null;
  const first = days[0];
  let last = days[days.length - 1];
  if (end && Number.isFinite(new Date(end).getTime())) { const e = dayIn(end, tz); if (e > last) last = e; }
  const span = daysBetween(first, last) + 1;
  const step = span > TIMELINE_DAILY_MAX ? 7 : 1;
  const points = [];
  for (let i = 0; i < span; i += step) points.push({ start: addDays(first, i), count: 0 });
  for (const d of days) points[Math.floor(daysBetween(first, d) / step)].count += 1;
  return { unit: step === 7 ? 'week' : 'day', timeZone: tz, first, last, points };
}

/** Median seconds per person over finished responses that recorded a time (D-54: median, not average). */
export function medianSeconds(responses) {
  const t = responses.filter((r) => r.completed && Number.isFinite(r.duration_seconds)).map((r) => r.duration_seconds).sort((a, b) => a - b);
  if (!t.length) return { seconds: null, timed: 0 };
  const m = t.length % 2 ? t[(t.length - 1) / 2] : (t[t.length / 2 - 1] + t[t.length / 2]) / 2;
  return { seconds: Math.round(m), timed: t.length };
}

/**
 * Sentiment levels on an SBI survey (D-54): each finished respondent counted once, at the
 * level their verified sentiment answers show (the riskiest, as for cohorts); people with
 * no verified sentiment answer are counted apart, never guessed. On anonymous surveys the
 * same floor as cohorts applies, the "not measured" group included, so no group under 5
 * can be read or worked out by subtraction.
 */
export function sentimentLevels(people, { anonymous = false, floor = ANONYMITY_FLOOR } = {}) {
  const total = people.length;
  if (!total) return null;
  const groups = [...RISK_ORDER.sentiment].reverse().map((key) => ({ key, count: people.filter((p) => p.sentiment === key).length }));
  groups.push({ key: 'not_measured', count: people.filter((p) => !p.sentiment).length });
  let shown = groups.map((g) => ({ ...g, pct: Math.round((100 * g.count) / total), hidden: false }));
  if (anonymous) shown = applyAnonymityFloor(shown.map((g) => ({ ...g, members: [] })), floor).cohorts.map(({ members, ...g }) => ({ ...g, hidden: !!g.hidden }));
  return { total, levels: shown.filter((g) => g.key !== 'not_measured'), notMeasured: shown.find((g) => g.key === 'not_measured') };
}

const isSignal = (s) => s && typeof s === 'object' && s.verified && typeof s.verified === 'object';

/** One respondent's three cohort signals, from verified pillars only. */
export function respondentSignals(answers) {
  const seen = { sentiment: new Set(), behaviour: new Set(), intent: new Set() };
  for (const a of answers) {
    const s = a.pillar_signal;
    if (!isSignal(s)) continue;
    for (const p of PILLARS) {
      if (s.verified[p] === true && typeof s.levels?.[p] === 'string') seen[p].add(s.levels[p]);
    }
  }
  const out = {};
  for (const p of PILLARS) out[p] = RISK_ORDER[p].find((lv) => seen[p].has(lv)) || null;
  return out;
}

function answerValue(q, a) {
  if (q.type === 'rating') return a.rating_value;
  if (q.type === 'nps') return a.nps_value;
  if (q.type === 'mc') return a.choice_selected;
  return a.text_response;
}

/**
 * @param {{survey:Object, questions:Array, responses:Array, answers:Array, now?:string}} rows
 *   survey     id, title, business_objective, status, mode, pillars_by, closed_at,
 *              iq_eligible, iq_rubric_version, iq_verdict_reason, iq_evaluated_at
 *   questions  id, position, text, type, options, pillars (ordered by position)
 *   responses  id, respondent_label, completed, last_question_position, submitted_at (ordered by submitted_at)
 *   answers    response_id, question_id, choice_selected, rating_value, nps_value,
 *              text_response, pillar_signal, verified_at, verification_attempts
 *   starts     (D-54, optional) {started, submitted, stoppedAt:{position:count}, since}
 *              from survey_starts. When anyone has started, completion and drop-off are
 *              measured from starts; before that they can't be (every stored response
 *              is a submitted one) and `completionMeasured` is false.
 */
export function buildLiveReport({ survey, questions, responses, answers, starts, now }, { maxAttempts = 3, withhold = true, timeZone = 'UTC' } = {}) {
  const qById = new Map(questions.map((q) => [q.id, q]));
  const maxPosition = questions.reduce((m, q) => Math.max(m, q.position), 0);
  const isSbi = survey.mode === 'sbi' && questions.some((q) => (q.pillars || []).length > 0);

  // ── standard analytics ─────────────────────────────────────────────────
  const total = responses.length;
  const completed = responses.filter((r) => r.completed).length;
  const measured = !!(starts && starts.started > 0);
  const byLastPosition = {};
  if (measured) {
    // D-54: everyone who started; submitters reached the end, the rest stopped where they stopped
    if (starts.submitted > 0) byLastPosition[maxPosition] = starts.submitted;
    for (const [p, n] of Object.entries(starts.stoppedAt || {})) {
      const pos = Math.min(Number(p), maxPosition);
      if (pos > 0) byLastPosition[pos] = (byLastPosition[pos] || 0) + n;
    }
  } else {
    for (const r of responses) {
      const p = r.completed ? maxPosition : r.last_question_position; // a finished survey reached the end, even if the last question was optional
      if (p > 0) byLastPosition[p] = (byLastPosition[p] || 0) + 1;
    }
  }
  const funnel = dropOffFunnel(byLastPosition, measured ? starts.started : total, maxPosition);

  const answersByQuestion = new Map(questions.map((q) => [q.id, []]));
  const answersByResponse = new Map(responses.map((r) => [r.id, []]));
  for (const a of answers) {
    if (!qById.has(a.question_id) || !answersByResponse.has(a.response_id)) continue;
    answersByQuestion.get(a.question_id).push(a);
    answersByResponse.get(a.response_id).push(a);
  }

  let npsDistribution = null;
  const perQuestion = questions.map((q) => {
    const list = answersByQuestion.get(q.id);
    const dist = {};
    if (q.type === 'mc') for (const o of q.options || []) dist[o] = 0; // keep the survey's option order
    if (q.type === 'rating') for (let n = 1; n <= 5; n += 1) dist[n] = 0; // the whole 1–5 scale, even unused points
    for (const a of list) {
      const v = answerValue(q, a);
      if (v === null || v === undefined || (q.type === 'open')) continue;
      dist[v] = (dist[v] || 0) + 1;
    }
    if (q.type === 'nps' && npsDistribution === null) npsDistribution = dist;
    const item = {
      id: q.id, position: q.position, text: q.text, type: q.type, pillars: q.pillars || [],
      answered: list.length,
      distribution: q.type === 'open' ? null : dist,
      uniformityPct: q.type === 'mc' ? uniformityPct(dist) : null,
      ratingAverage: q.type === 'rating' ? ratingAverage(dist).average : null,
      nps: q.type === 'nps' ? computeNps(dist) : null,
    };
    if (q.type === 'open') {
      item.samples = list.filter((a) => a.text_response).slice(-OPEN_TEXT_SAMPLE).reverse().map((a) => a.text_response);
    }
    return item;
  });
  const mcUniformity = perQuestion.filter((q) => q.type === 'mc' && q.answered > 0).map((q) => q.uniformityPct);
  const worstUniformity = mcUniformity.length ? Math.max(...mcUniformity) : 0;

  const metrics = {
    responses: total,
    completed,
    // D-54: measured from starts once anyone has started; otherwise only submitted responses exist
    completionPct: measured ? completionPct(starts.submitted, starts.started) : completionPct(completed, total),
    completionMeasured: measured,
    started: measured ? starts.started : null,
    finishedOfStarted: measured ? starts.submitted : null,
    measuredSince: measured ? starts.since : null,
    nps: npsDistribution ? computeNps(npsDistribution) : null,
    dropOffRate: funnel.dropOffRate,
    leftEarly: funnel.steps.length ? funnel.total - funnel.steps[funnel.steps.length - 1].reached : 0,
    biggestDropPosition: funnel.biggestDropPosition,
    funnel: funnel.steps.map((s) => ({ position: s.position, reachedPct: s.reachedPct })),
    uniformityPct: worstUniformity,
    medianTime: medianSeconds(responses),
  };

  const base = {
    version: REPORT_VERSION,
    engine: ENGINE,
    generatedAt: now || new Date().toISOString(),
    survey: {
      id: survey.id, title: survey.title, objective: survey.business_objective || null,
      status: survey.status, mode: survey.mode, anonymous: survey.anonymous !== false,
      audienceSize: Number.isInteger(survey.audience_size) ? survey.audience_size : null,
      publishedAt: survey.published_at || null, closedAt: survey.closed_at || null,
      coverageMode: coverageMode({ mode: survey.mode, pillarsBy: survey.pillars_by, hasPillars: isSbi }),
    },
    metrics,
    questions: perQuestion,
    timeline: responseTimeline(responses, {
      tz: safeTimeZone(timeZone),
      end: survey.status === 'active' ? (now || new Date().toISOString()) : (survey.closed_at || null),
    }),
  };

  // ── verification progress (SBI only) ───────────────────────────────────
  let verification = null;
  let signalQuality = null;
  let cohorts = null;
  let verifiedTotal = 0;
  let distinct = 0;
  if (isSbi) {
    const toCheck = answers.filter((a) => (qById.get(a.question_id)?.pillars || []).length > 0 && answersByResponse.has(a.response_id));
    const checked = toCheck.filter((a) => a.verified_at && isSignal(a.pillar_signal));
    const failed = toCheck.filter((a) => !a.verified_at && (a.verification_attempts || 0) >= maxAttempts);
    verification = { answers: toCheck.length, checked: checked.length, couldNotCheck: failed.length, pending: toCheck.length - checked.length - failed.length };

    // Dual view: one record per question, built from its answers' signals.
    const records = questions.filter((q) => (q.pillars || []).length > 0).map((q) => {
      const delivered = {};
      const reclassified = {};
      for (const a of answersByQuestion.get(q.id)) {
        const s = a.pillar_signal;
        if (!a.verified_at || !isSignal(s)) continue;
        for (const p of PILLARS) {
          if (s.verified[p] === true && (q.pillars || []).includes(p)) delivered[p] = (delivered[p] || 0) + 1;
          if (s.actual?.[p] === true && !(q.pillars || []).includes(p)) reclassified[p] = (reclassified[p] || 0) + 1;
        }
      }
      const verified = Object.fromEntries((q.pillars || []).map((p) => [p, (delivered[p] || 0) > 0]));
      return { verified, delivered, reclassified };
    });
    const views = dualView(records);
    verifiedTotal = PILLARS.reduce((n, p) => n + (views.verified[p] || 0), 0);
    distinct = distinctPillarsDelivered(views.verified);
    signalQuality = {
      verified: views.verified,
      generic: views.generic,
      minNGates: Object.fromEntries(PILLARS.map((p) => [p, minNGate(views.verified[p] || 0)])),
      pillarScores: Object.fromEntries(PILLARS.map((p) => {
        const gate = minNGate(views.verified[p] || 0);
        return [p, gate.status === 'ok' ? pillarScoreFlat(views.verified[p] || 0, checked.length) : null];
      })),
    };

    const people = responses.filter((r) => r.completed).map((r) => {
      const index = responses.indexOf(r) + 1;
      return { id: r.id, name: r.respondent_label || `Respondent ${index}`, ...respondentSignals(answersByResponse.get(r.id)) };
    });
    const summary = cohortSummary(people);
    cohorts = summary.cohorts;
    const withSignal = people.filter((p) => p.sentiment || p.behaviour || p.intent).length;
    base.classified = { total: summary.total, withSignal };
    base.sentimentLevels = sentimentLevels(people, { anonymous: base.survey.anonymous });
    if (base.survey.anonymous) {
      const floored = applyAnonymityFloor(cohorts);
      cohorts = floored.cohorts;
      const unclassified = summary.total - withSignal;
      base.anonymity = { floor: ANONYMITY_FLOOR, hiddenCohorts: floored.hidden, unclassifiedHidden: unclassified > 0 && unclassified < ANONYMITY_FLOOR };
      // The unclassified count is a group of people too: under the floor, only "some" is said.
      if (base.anonymity.unclassifiedHidden) base.classified = { total: summary.total, withSignal: null };
    }
    // D-48: BoloBit intuitive analysis (star math) on the same people and levels as the cohorts.
    base.intuition = intuitiveAnalysis(
      responses.filter((r) => r.completed).map((r) => ({ id: r.id, name: r.respondent_label || `Respondent ${responses.indexOf(r) + 1}`, answers: answersByResponse.get(r.id) })),
      qById,
      { anonymous: base.survey.anonymous, floor: ANONYMITY_FLOOR, hiddenCohorts: base.anonymity?.hiddenCohorts || [] },
    );
  }

  // ── eligibility gate ────────────────────────────────────────────────────
  const audienceSize = base.survey.audienceSize ?? undefined;
  let gate;
  if (survey.iq_evaluated_at && survey.iq_verdict_reason) {
    gate = {
      final: true, rubricVersion: survey.iq_rubric_version, eligible: survey.iq_eligible,
      criteria: survey.iq_verdict_reason, evaluatedAt: survey.iq_evaluated_at,
      requiredResponses: requiredResponses({ rubricVersion: survey.iq_rubric_version, audienceSize }),
    };
  } else {
    const g = evaluateGate({
      responses: total, completionPct: metrics.completionPct, verifiedSignalCount: verifiedTotal,
      uniformityPct: worstUniformity, mode: survey.mode, distinctPillars: distinct,
      llmVerdict: undefined, rubricVersion: CURRENT_RUBRIC, audienceSize,
    });
    const rulesFailed = g.criteria.single_purpose.pass === null;
    const criteria = { ...g.criteria };
    if (!rulesFailed) criteria.single_purpose = { pass: null, reason: 'Checked when the survey closes' };
    gate = {
      final: false, rubricVersion: g.rubric_version, eligible: rulesFailed ? false : null, criteria, evaluatedAt: null,
      requiredResponses: requiredResponses({ rubricVersion: g.rubric_version, audienceSize }),
    };
  }

  // ── distribution base (2026-11-12): small bases are flagged, tiny ones withheld ─
  const baseSize = base.survey.audienceSize ?? total;
  const small = baseSize < MIN_BASE;
  const tinyBase = small && total > 0 && total < MIN_ANALYSED;
  const belowAnonymityFloor = base.survey.anonymous && total > 0 && total < ANONYMITY_FLOOR;
  const withheld = tinyBase || belowAnonymityFloor;
  const distribution = {
    size: baseSize, source: base.survey.audienceSize ? 'audience' : 'respondents',
    minimum: MIN_BASE, minimumResponses: MIN_ANALYSED, small, withheld,
    withheldReason: tinyBase ? 'small_base' : belowAnonymityFloor ? 'anonymity' : null,
    // Under 30 responses percentages swing widely: the page leads with counts and says so.
    lowResponses: total > 0 && total < LOW_RESPONSES, lowResponsesBelow: LOW_RESPONSES,
  };
  if (total === 0 && withhold) {
    // D-40: no report is built from zero responses. The page says there is nothing to
    // analyse and what to do next; no zero figures, cohorts or eligibility are shown.
    return {
      version: base.version, engine: base.engine, generatedAt: base.generatedAt, survey: base.survey,
      empty: true, metrics: { responses: 0, completed: 0 },
      questions: null, distribution: null, verification: null, signalQuality: null, cohorts: null, gate: null,
    };
  }
  if (withheld && withhold) {
    // Fewer than 5 responses from a base under 15, or fewer than 5 on an anonymous
    // survey: no figure leaves the server, so no finding rests on one or two people
    // and no respondent can be singled out.
    // D-45: the usual report, without the analysis. A named survey still shows its
    // answers as counts (people chose to give their name); an anonymous one shows
    // no answers and no score that a handful of answers would give away (D-28).
    const named = !base.survey.anonymous;
    return {
      ...base,
      metrics: {
        responses: total, completed, completionPct: metrics.completionPct, nps: named ? metrics.nps : null,
        completionMeasured: metrics.completionMeasured, started: metrics.started, finishedOfStarted: metrics.finishedOfStarted, measuredSince: metrics.measuredSince,
        dropOffRate: metrics.dropOffRate, leftEarly: metrics.leftEarly, biggestDropPosition: metrics.biggestDropPosition,
        funnel: metrics.funnel, uniformityPct: null,
        medianTime: named ? metrics.medianTime : null,
      },
      timeline: named ? base.timeline : null,
      questions: named ? perQuestion : null,
      distribution, verification, signalQuality: null, cohorts: null, classified: undefined, anonymity: undefined, intuition: undefined, sentimentLevels: undefined, gate,
    };
  }
  return { ...base, distribution, verification, signalQuality, cohorts, gate };
}

/** Inputs for the gate, so the close step can call the engine with the same numbers the report shows. */
export function gateInputs(report) {
  return {
    responses: report.metrics.responses,
    audienceSize: report.survey.audienceSize ?? undefined,
    completionPct: report.metrics.completionPct,
    verifiedSignalCount: report.signalQuality ? PILLARS.reduce((n, p) => n + (report.signalQuality.verified[p] || 0), 0) : 0,
    uniformityPct: report.metrics.uniformityPct,
    mode: report.survey.mode,
    distinctPillars: report.signalQuality ? distinctPillarsDelivered(report.signalQuality.verified) : 0,
  };
}
