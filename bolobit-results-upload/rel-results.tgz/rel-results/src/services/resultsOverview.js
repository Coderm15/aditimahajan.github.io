/**
 * @fileoverview S8 Results overview (D-54): the business's own numbers for a period.
 *
 * Rules (decided by Amarjot, 2026-11-24):
 *   - No industry averages, no "Good"/"Excellent" labels.
 *   - Change against the previous period only when that period has responses.
 *   - Completion = people who finished ÷ people who started, from counted starts only;
 *     null ("Not measured") when nobody in the period was counted.
 *   - NPS = all 0–10 answers in the period pooled, with how many answers it rests on.
 *   - Median time per person, not average.
 *   - Anonymity (D-28): an anonymous survey under 5 responses shows no NPS, and its
 *     0–10 answers stay out of the pooled NPS, so a handful of answers is never exposed.
 */

import { computeNps, completionPct } from '../engine/scoring.js';
import { ANONYMITY_FLOOR } from './surveyReport.js';

export const PERIODS = Object.freeze({ 30: 30, 90: 90, 365: 365, all: null });
export const DEFAULT_PERIOD = '90';
const DAY_MS = 86_400_000;

/** `since` for a period key, or null for all time. Throws on an unknown key. */
export function periodStart(period, now = new Date()) {
  if (!Object.prototype.hasOwnProperty.call(PERIODS, period)) throw new RangeError('Unknown period');
  const days = PERIODS[period];
  return days === null ? null : new Date(now.getTime() - days * DAY_MS);
}

const countOf = (dist) => Object.values(dist || {}).reduce((n, c) => n + (Number(c) || 0), 0);

function addInto(target, dist) {
  for (const [k, c] of Object.entries(dist || {})) target[k] = (target[k] || 0) + (Number(c) || 0);
}

/**
 * @param {{rows:Array, median:{seconds:number|null,timed:number}, previous:number|null,
 *          active:number, period:string, since:Date|null}} input
 *   rows      from SurveyResults.surveyRows
 *   previous  responses in the period before (null for all time)
 */
export function buildOverview({ rows, median, previous, active, period, since }) {
  const pooledNps = {};
  let started = 0;
  let finished = 0;
  let responses = 0;

  const surveys = rows.map((r) => {
    const protectedNps = r.anonymous && r.responses_all_time < ANONYMITY_FLOOR;
    const npsAnswers = protectedNps ? 0 : countOf(r.nps_distribution);
    if (!protectedNps) addInto(pooledNps, r.nps_distribution);
    started += r.started;
    finished += r.finished;
    responses += r.responses;
    return {
      id: r.id,
      title: r.title,
      status: r.status,
      mode: r.mode,
      responses: r.responses,
      completion: r.started > 0 ? { pct: completionPct(r.finished, r.started), finished: r.finished, started: r.started } : null,
      nps: npsAnswers > 0 ? { score: computeNps(r.nps_distribution), answers: npsAnswers } : null,
      npsHidden: protectedNps && countOf(r.nps_distribution) > 0,
    };
  });

  const npsAnswers = countOf(pooledNps);
  const change = previous && previous > 0 ? Math.round((100 * (responses - previous)) / previous) : null;

  return {
    period,
    since: since ? since.toISOString() : null,
    tiles: {
      responses: { total: responses, previous: previous ?? null, changePct: change },
      completion: started > 0 ? { pct: completionPct(finished, started), finished, started } : null,
      nps: npsAnswers > 0 ? { score: computeNps(pooledNps), answers: npsAnswers } : null,
      active,
      medianTime: median.seconds === null ? null : { seconds: median.seconds, timed: median.timed },
    },
    surveys,
  };
}
