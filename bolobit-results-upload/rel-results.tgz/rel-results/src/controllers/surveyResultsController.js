/**
 * @fileoverview GET /api/v1/surveys/results?period=30|90|365|all — S8 Results overview (D-54).
 */

import * as Survey from '../models/Survey.js';
import * as SurveyResults from '../models/SurveyResults.js';
import { buildOverview, periodStart, PERIODS, DEFAULT_PERIOD } from '../services/resultsOverview.js';

const fail = (res, status, message) => res.status(status).json({ success: false, message });

export async function getResults(req, res, next) {
  try {
    const businessId = await Survey.resolveBusinessId(req.user.id);
    if (!businessId) return fail(res, 403, 'Complete business onboarding first');
    const period = req.query.period === undefined ? DEFAULT_PERIOD : String(req.query.period);
    if (!Object.prototype.hasOwnProperty.call(PERIODS, period)) return fail(res, 400, 'Unknown period');

    const now = new Date();
    const since = periodStart(period, now);
    const before = since ? new Date(since.getTime() - (now.getTime() - since.getTime())) : null;
    const [rows, median, previous, active] = await Promise.all([
      SurveyResults.surveyRows(businessId, since),
      SurveyResults.medianTime(businessId, since),
      since ? SurveyResults.responsesBetween(businessId, before, since) : Promise.resolve(null),
      SurveyResults.activeCount(businessId),
    ]);
    return res.json({ success: true, data: buildOverview({ rows, median, previous, active, period, since }) });
  } catch (err) { return next(err); }
}
