/**
 * @fileoverview GET /api/v1/surveys/:id/report — the live report (R3c).
 * Built on request from stored rows by the pinned engine, so it is always
 * current. Answers still waiting for their check are retried in the
 * background; the report says how many are pending.
 */

import * as Survey from '../models/Survey.js';
import * as SurveyReport from '../models/SurveyReport.js';
import { isUuid } from '../utils/surveyValidation.js';
import { buildLiveReport } from '../services/surveyReport.js';
import { verifyPending, MAX_ATTEMPTS } from '../services/verification.js';
import { finalizeLater } from '../services/surveyFinalize.js';

const fail = (res, status, message) => res.status(status).json({ success: false, message });
const retrying = new Map(); // surveyId -> last retry (ms); one background retry per survey per minute
const RETRY_EVERY_MS = Number(process.env.REPORT_RETRY_MS || 60_000);

export async function getReport(req, res, next) {
  try {
    const businessId = await Survey.resolveBusinessId(req.user.id);
    if (!businessId) return fail(res, 403, 'Complete business onboarding first');
    if (!isUuid(req.params.id)) return fail(res, 400, 'Invalid survey id');

    const rows = await SurveyReport.loadRows(req.params.id, businessId);
    if (!rows) return fail(res, 404, 'Survey not found');
    if (rows.survey.status === 'draft') return fail(res, 409, 'A report is available once the survey is published');

    const report = buildLiveReport(rows, { maxAttempts: MAX_ATTEMPTS, timeZone: typeof req.query.tz === 'string' ? req.query.tz : 'UTC' });
    res.json({ success: true, data: { report } });

    // After answering: catch up on unchecked answers, and settle the verdict of a closed survey.
    const id = rows.survey.id;
    const due = (retrying.get(id) || 0) + RETRY_EVERY_MS < Date.now();
    const closed = ['closed', 'archived'].includes(rows.survey.status);
    if (due && (report.verification?.pending > 0 || (closed && !rows.survey.iq_evaluated_at))) {
      retrying.set(id, Date.now());
      if (closed) finalizeLater(id, businessId);
      else setImmediate(() => { verifyPending(id).catch(() => {}); });
    }
    return undefined;
  } catch (err) { return next(err); }
}
