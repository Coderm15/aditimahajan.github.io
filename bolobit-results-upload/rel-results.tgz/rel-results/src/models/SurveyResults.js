/**
 * @fileoverview Rows for the S8 Results overview (D-54). Every query is scoped to one
 * business. Drafts and archived surveys are left out: drafts have no results, and
 * archived surveys (where test surveys go) are out of the business's view.
 *
 * "In the period" means: responses submitted, and starts begun, on or after `since`.
 * A survey belongs to the period when it was collecting at any time in it
 * (still live, or closed on or after `since`). `since = null` is all time.
 */

import pool from '../config/database.js';

/** One row per live or closed survey in the period, with that period's raw counts. */
export async function surveyRows(businessId, since) {
  const { rows } = await pool.query(
    `SELECT s.id, s.title, s.status, s.mode, s.anonymous, s.published_at, s.closed_at,
            (SELECT count(*)::int FROM survey_responses r
              WHERE r.survey_id = s.id AND r.submitted_at IS NOT NULL
                AND ($2::timestamptz IS NULL OR r.submitted_at >= $2::timestamptz)) AS responses,
            (SELECT count(*)::int FROM survey_responses r
              WHERE r.survey_id = s.id AND r.submitted_at IS NOT NULL) AS responses_all_time,
            (SELECT count(*)::int FROM survey_starts st
              WHERE st.survey_id = s.id AND ($2::timestamptz IS NULL OR st.started_at >= $2::timestamptz)) AS started,
            (SELECT count(*)::int FROM survey_starts st
              WHERE st.survey_id = s.id AND st.response_id IS NOT NULL
                AND ($2::timestamptz IS NULL OR st.started_at >= $2::timestamptz)) AS finished,
            (SELECT COALESCE(json_object_agg(d.v, d.n), '{}'::json) FROM (
               SELECT a.nps_value AS v, count(*)::int AS n
                 FROM survey_answers a JOIN survey_responses r ON r.id = a.response_id
                WHERE r.survey_id = s.id AND a.nps_value IS NOT NULL AND r.submitted_at IS NOT NULL
                  AND ($2::timestamptz IS NULL OR r.submitted_at >= $2::timestamptz)
                GROUP BY a.nps_value) d) AS nps_distribution
       FROM surveys s
      WHERE s.business_id = $1 AND s.status IN ('active', 'closed')
        AND ($2::timestamptz IS NULL OR s.status = 'active' OR s.closed_at IS NULL OR s.closed_at >= $2::timestamptz)
      ORDER BY (s.status = 'active') DESC, s.published_at DESC NULLS LAST, s.created_at DESC`,
    [businessId, since],
  );
  return rows;
}

/** Median seconds per person (finished responses with a recorded time) in the period. */
export async function medianTime(businessId, since) {
  const { rows } = await pool.query(
    `SELECT percentile_cont(0.5) WITHIN GROUP (ORDER BY r.duration_seconds) AS median, count(*)::int AS n
       FROM survey_responses r JOIN surveys s ON s.id = r.survey_id
      WHERE s.business_id = $1 AND s.status IN ('active', 'closed')
        AND r.completed AND r.duration_seconds IS NOT NULL AND r.submitted_at IS NOT NULL
        AND ($2::timestamptz IS NULL OR r.submitted_at >= $2::timestamptz)`,
    [businessId, since],
  );
  const { median, n } = rows[0];
  return { seconds: median === null ? null : Math.round(Number(median)), timed: n };
}

/** Responses submitted in [from, to): the period before, for the change figure. */
export async function responsesBetween(businessId, from, to) {
  const { rows } = await pool.query(
    `SELECT count(*)::int AS n
       FROM survey_responses r JOIN surveys s ON s.id = r.survey_id
      WHERE s.business_id = $1 AND s.status IN ('active', 'closed')
        AND r.submitted_at >= $2::timestamptz AND r.submitted_at < $3::timestamptz`,
    [businessId, from, to],
  );
  return rows[0].n;
}

/** Surveys collecting right now. */
export async function activeCount(businessId) {
  const { rows } = await pool.query(
    `SELECT count(*)::int AS n FROM surveys WHERE business_id = $1 AND status = 'active'`,
    [businessId],
  );
  return rows[0].n;
}
