/**
 * @fileoverview Answer verification (Master Spec §7, Handover §9 + Appendix A).
 *
 * A question's pillars are a CLAIM; this checks, answer by answer, whether the
 * answer actually delivers them. Output stored in survey_answers.pillar_signal:
 *
 *   { v: 1, declared: ['intent'], verified: { intent: false },
 *     actual: { sentiment: true }, levels: { sentiment: 'negative' },
 *     reason: 'expresses tone, not a stated intention', model: '…' }
 *
 *   verified  one boolean per DECLARED pillar. Only `true` ever counts as verified.
 *   actual    pillars the answer carries that were NOT declared (generic view only, §7.7).
 *   levels    for each pillar marked true: what the answer shows. These feed the
 *             cohort flags (unhappy / disengaged / wavering), verified pillars only.
 *
 * Fail-safe (§7.4): no key, timeout, error or unparseable reply ⇒ the answer stays
 * unverified (pillar_signal NULL). Never "assumed present". Respondents never wait:
 * this runs after the response has been sent (§7.3).
 */

import crypto from 'node:crypto';
import pool from '../config/database.js';
import { tierFor } from '../config/llm.js';
import { complete as defaultComplete, extractJson } from './llmClient.js';

export const PILLARS = Object.freeze(['sentiment', 'behaviour', 'intent']);
export const LEVELS = Object.freeze({
  sentiment: Object.freeze(['positive', 'neutral', 'negative']),
  behaviour: Object.freeze(['engaged', 'neutral', 'disengaged']),
  intent: Object.freeze(['committed', 'wavering', 'at_risk']),
});
/** An answer the model answered but we could not use is retried at most this often. */
export const MAX_ATTEMPTS = 3;

const RATING_LABELS = ['very poor', 'poor', 'okay', 'good', 'excellent'];

export const SYSTEM_PROMPT = `You check ONE survey answer against the signal its question was designed to measure.

The three pillars:
- sentiment: how the respondent FEELS (satisfaction, frustration, delight)
- behaviour: what the respondent DOES or DID (usage, frequency, actions taken)
- intent: what the respondent WILL DO next (renew, leave, recommend, buy more)

You are given the question, the pillars it was designed to measure ("declared"), and the answer.

1. For EACH declared pillar, decide whether THIS ANSWER actually carries that signal.
   FINDING NO SIGNAL IS VALID, EXPECTED AND ACCEPTABLE. Short, vague, off-topic or
   joking answers often carry none. Never stretch an answer to fit; a wrong "true"
   is far more costly than an honest "false".
2. If the answer clearly carries a pillar that was NOT declared, list it under "actual".
   Otherwise leave "actual" empty.
3. For every pillar you mark true (declared or actual), give the level the answer shows:
   sentiment: positive | neutral | negative
   behaviour: engaged | neutral | disengaged   (disengaged = low, falling or stopped use)
   intent:    committed | wavering | at_risk   (wavering = undecided; at_risk = leaving or unlikely to stay)
4. A comment, when present, is the respondent's own words about this question. Read it as part of the answer:
   it can confirm a declared pillar or carry one that was not declared.
5. reason: one short sentence.

Reply with JSON only, no prose and no markdown fences:
{"verified":{"intent":false},"actual":{"sentiment":true},"levels":{"sentiment":"negative"},"reason":"expresses tone, not a stated intention"}`;

/** The answer as the model reads it. */
export function describeAnswer(question, answer) {
  let main;
  if (question.type === 'rating' && answer.rating_value != null) {
    main = `${answer.rating_value} out of 5 (${RATING_LABELS[answer.rating_value - 1]})`;
  } else if (question.type === 'nps' && answer.nps_value != null) {
    main = `${answer.nps_value} out of 10 on how likely they are to recommend`;
  } else if (question.type === 'mc' && answer.choice_selected != null) {
    main = `chose "${answer.choice_selected}" from: ${(question.options || []).map((o) => `"${o}"`).join(', ')}`;
  } else {
    main = answer.text_response != null ? `"${answer.text_response}"` : '(no answer)';
  }
  return answer.comment ? `${main}; comment: "${answer.comment}"` : main;
}

export function userPrompt(question, answer) {
  return `Question: "${question.text}"\nDeclared pillars: ${question.pillars.join(', ')}\nAnswer: ${describeAnswer(question, answer)}`;
}

/**
 * Whitelist the model's reply into a pillar_signal, or null when unusable.
 * Every declared pillar gets an explicit boolean; nothing undeclared can become verified.
 */
export function normaliseVerdict(parsed, declared, model) {
  if (!parsed || typeof parsed !== 'object' || typeof parsed.verified !== 'object' || parsed.verified === null) return null;
  const decl = declared.filter((p) => PILLARS.includes(p));
  if (!decl.length) return null;

  const verified = {};
  for (const p of decl) verified[p] = parsed.verified[p] === true;

  const actual = {};
  if (parsed.actual && typeof parsed.actual === 'object') {
    for (const p of PILLARS) if (!decl.includes(p) && parsed.actual[p] === true) actual[p] = true;
  }

  const levels = {};
  const rawLevels = parsed.levels && typeof parsed.levels === 'object' ? parsed.levels : {};
  for (const p of PILLARS) {
    if (verified[p] !== true && actual[p] !== true) continue;
    const lv = typeof rawLevels[p] === 'string' ? rawLevels[p].trim().toLowerCase().replace(/[\s-]+/g, '_') : null;
    if (LEVELS[p].includes(lv)) levels[p] = lv;
  }

  const reason = typeof parsed.reason === 'string' ? parsed.reason.slice(0, 300) : '';
  return { v: 1, declared: decl, verified, actual, levels, reason, model };
}

// In-process cache (§7.5): identical question + pillars + answer is never billed twice.
const CACHE_MAX = 5000;
const cache = new Map();
const cacheKey = (q, a) => crypto.createHash('sha256').update(JSON.stringify([q.text, q.type, [...q.pillars].sort(), q.options || [], describeAnswer(q, a)])).digest('hex');
export function clearCache() { cache.clear(); }

/**
 * Verify one answer. Returns { signal, retryable }:
 *   signal     the pillar_signal, or null (unverified)
 *   retryable  true when the model was unreachable (no attempt is spent)
 */
export async function verifyAnswer(question, answer, { complete = defaultComplete } = {}) {
  const key = cacheKey(question, answer);
  if (cache.has(key)) return { signal: cache.get(key), retryable: false, cached: true };

  const cfg = tierFor('pillar_verification');
  let raw;
  try {
    raw = await complete({ model: cfg.model, maxTokens: cfg.maxTokens, temperature: cfg.temperature, system: SYSTEM_PROMPT, user: userPrompt(question, answer) });
  } catch {
    // No key, timeout, network or API error: try again on the next trigger (close, report view).
    return { signal: null, retryable: true };
  }
  const signal = normaliseVerdict(extractJson(raw), question.pillars, cfg.model);
  if (signal) {
    if (cache.size >= CACHE_MAX) cache.delete(cache.keys().next().value);
    cache.set(key, signal);
  }
  return { signal, retryable: false };
}

// ── persistence ────────────────────────────────────────────────────────────
// Background work keyed by ids the API itself created; every query still
// joins through the survey so an answer can't be reached from another survey.

const PENDING_SQL = `
  SELECT a.id, a.choice_selected, a.rating_value, a.nps_value, a.text_response, a.comment,
         q.id AS question_id, q.text, q.type, q.options, q.pillars
    FROM survey_answers a
    JOIN survey_responses r ON r.id = a.response_id
    JOIN survey_questions q ON q.id = a.question_id AND q.survey_id = r.survey_id
    JOIN surveys s ON s.id = r.survey_id
   WHERE r.survey_id = $1
     AND s.mode = 'sbi'
     AND jsonb_array_length(q.pillars) > 0
     AND a.verified_at IS NULL
     AND a.verification_attempts < $2`;

async function pendingFor(surveyId, responseId) {
  const sql = responseId ? `${PENDING_SQL} AND r.id = $3 ORDER BY q.position` : `${PENDING_SQL} ORDER BY r.submitted_at, q.position`;
  const params = responseId ? [surveyId, MAX_ATTEMPTS, responseId] : [surveyId, MAX_ATTEMPTS];
  const { rows } = await pool.query(sql, params);
  return rows.map((r) => ({
    answer: { id: r.id, choice_selected: r.choice_selected, rating_value: r.rating_value, nps_value: r.nps_value, text_response: r.text_response, comment: r.comment },
    question: { id: r.question_id, text: r.text, type: r.type, options: r.options || [], pillars: r.pillars || [] },
  }));
}

async function save(answerId, { signal, retryable }) {
  if (signal) {
    await pool.query(
      `UPDATE survey_answers SET pillar_signal = $2::jsonb, verified_at = NOW(),
              verification_attempts = LEAST(verification_attempts + 1, 10)
        WHERE id = $1 AND verified_at IS NULL`,
      [answerId, JSON.stringify(signal)],
    );
  } else if (!retryable) {
    // The model answered but the reply was unusable: spend an attempt, stay unverified.
    await pool.query('UPDATE survey_answers SET verification_attempts = LEAST(verification_attempts + 1, 10) WHERE id = $1 AND verified_at IS NULL', [answerId]);
  }
}

/** Verify what is pending for one survey (or one response of it). Never throws. */
export async function verifyPending(surveyId, { responseId = null, complete = defaultComplete, concurrency = 4 } = {}) {
  const summary = { checked: 0, verified: 0, unverified: 0, unreachable: 0 };
  let items;
  try { items = await pendingFor(surveyId, responseId); } catch { return summary; }
  let next = 0;
  async function worker() {
    while (next < items.length) {
      const { answer, question } = items[next++];
      try {
        const out = await verifyAnswer(question, answer, { complete });
        await save(answer.id, out);
        summary.checked += 1;
        if (out.signal) summary.verified += 1;
        else if (out.retryable) summary.unreachable += 1;
        else summary.unverified += 1;
      } catch { summary.unverified += 1; }
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, worker));
  return summary;
}

/** The afterSubmit hook for the public respondent path: fire and forget. */
export function verifyResponseLater({ surveyId, responseId }) {
  verifyPending(surveyId, { responseId }).catch(() => {});
}
