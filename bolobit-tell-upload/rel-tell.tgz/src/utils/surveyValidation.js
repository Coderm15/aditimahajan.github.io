/**
 * @fileoverview Survey-domain validators (Phase 1 Code spec §5.1). Pure: no DB,
 * no HTTP. Each validator returns { valid: true } or { valid: false, message }.
 */

export const CATEGORIES = Object.freeze(['Product', 'Experience', 'Event', 'Device', 'Service']);
export const STATUSES = Object.freeze(['draft', 'active', 'closed', 'archived']);
export const MODES = Object.freeze(['std', 'sbi', 'man']);
export const CHANNELS = Object.freeze(['link', 'email', 'restricted', 'embed']);
export const ACTIVE_CHANNELS = Object.freeze(['link']);
export const Q_TYPES = Object.freeze(['rating', 'mc', 'open', 'nps']);
export const PILLARS = Object.freeze(['sentiment', 'behaviour', 'intent']);
export const BULK_ACTIONS = Object.freeze(['duplicate', 'archive', 'delete']);
export const LIMITS = Object.freeze({
  title: 200, description: 2000, audience: 100, objective: 1000, question: 500,
  options: 10, option: 200, questions: 50, open: 5000, comment: 1000, maxResponses: 1_000_000, audienceMin: 1, audienceMax: 1_000_000,
  respondentLabel: 120,
});

const OK = Object.freeze({ valid: true });
const bad = (message) => ({ valid: false, message });
const isStr = (v) => typeof v === 'string';
const blank = (v) => !isStr(v) || v.trim() === '';

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
export const isUuid = (v) => isStr(v) && UUID_RE.test(v);
export const isEmail = (v) => isStr(v) && v.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);

const EDGES = Object.freeze({
  draft: ['active', 'archived'],
  active: ['closed', 'archived'],
  closed: ['archived'],
  archived: [],
});

const STATE_NAME = Object.freeze({ draft: 'A draft', active: 'A live', closed: 'A closed', archived: 'An archived' });
const STATE_VERB = Object.freeze({ draft: 'turned back into a draft', active: 'made live again', closed: 'closed', archived: 'archived again' });

/** Legal lifecycle edges only (no same-state, reopen, un-publish or un-archive). */
export function canTransition(from, to) {
  if (!EDGES[from] || !STATUSES.includes(to)) return bad('Unknown survey status');
  if (!EDGES[from].includes(to)) return bad(`${STATE_NAME[from]} survey can’t be ${STATE_VERB[to]}`);
  return OK;
}

/** Today as YYYY-MM-DD in UTC: a deadline is open until 23:59:59.999 UTC that day. */
export const todayUtc = (now = new Date()) => now.toISOString().slice(0, 10);
export const PAST_DEADLINE = 'The deadline can’t be in the past. Deadlines end at midnight UTC.';

function isIsoDate(v) {
  if (!isStr(v) || !/^\d{4}-\d{2}-\d{2}$/.test(v)) return false;
  const d = new Date(`${v}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === v;
}

/** Setup step fields. With partial, absent fields are skipped (PATCH). */
export function validateSurveyInput(body, { partial = false, today = todayUtc() } = {}) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) return bad('Send the survey details as a JSON object');
  const has = (k) => Object.prototype.hasOwnProperty.call(body, k);
  if (!partial || has('title')) {
    if (blank(body.title)) return bad('Give the survey a title');
    if (body.title.trim().length > LIMITS.title) return bad(`Keep the title under ${LIMITS.title} characters`);
  }
  if (!partial || has('category')) {
    if (!CATEGORIES.includes(body.category)) return bad(`Choose a category: ${CATEGORIES.join(', ')}`);
  }
  if (has('description') && body.description !== null && (!isStr(body.description) || body.description.length > LIMITS.description)) {
    return bad(`Keep the description under ${LIMITS.description} characters`);
  }
  if (has('audience') && body.audience !== null && (!isStr(body.audience) || body.audience.length > LIMITS.audience)) {
    return bad(`Keep the audience under ${LIMITS.audience} characters`);
  }
  if (has('business_objective') && body.business_objective !== null
      && (!isStr(body.business_objective) || body.business_objective.length > LIMITS.objective)) {
    return bad(`Keep the business question under ${LIMITS.objective} characters`);
  }
  if (has('deadline') && body.deadline !== null && body.deadline !== '') {
    if (!isIsoDate(body.deadline)) return bad('Use a real date for the deadline (YYYY-MM-DD)');
    if (body.deadline < today) return bad(PAST_DEADLINE);
  }
  if (has('mode') && !MODES.includes(body.mode)) return bad('Unknown survey mode');
  return OK;
}

/** The full question list for a survey in the given mode. */
export function validateQuestions(questions, mode = 'man') {
  if (!Array.isArray(questions)) return bad('Send the questions as a list');
  if (questions.length < 1) return bad('Add at least one question');
  if (questions.length > LIMITS.questions) return bad(`A survey can have up to ${LIMITS.questions} questions`);
  for (let i = 0; i < questions.length; i += 1) {
    const q = questions[i];
    const n = `Question ${i + 1}`;
    if (!q || typeof q !== 'object') return bad(`${n} is not valid`);
    if (blank(q.text)) return bad(`${n} needs text`);
    if (q.text.trim().length > LIMITS.question) return bad(`${n} is longer than ${LIMITS.question} characters`);
    if (!Q_TYPES.includes(q.type)) return bad(`${n} has an unknown type`);
    const options = q.options ?? [];
    if (!Array.isArray(options) || options.length > LIMITS.options) return bad(`${n} can have up to ${LIMITS.options} options`);
    if (options.some((o) => blank(o) || o.trim().length > LIMITS.option)) return bad(`${n} has an empty or too-long option`);
    if (new Set(options.map((o) => o.trim().toLowerCase())).size !== options.length) return bad(`${n} has duplicate options`);
    if (q.type === 'mc' && options.length < 2) return bad(`${n} needs at least two options`);
    if (q.type !== 'mc' && options.length > 0) return bad(`${n} only takes options when it is multiple choice`);
    const pillars = q.pillars ?? [];
    if (!Array.isArray(pillars) || pillars.some((p) => !PILLARS.includes(p)) || new Set(pillars).size !== pillars.length) {
      return bad(`${n} has an unknown pillar`);
    }
    if (mode === 'sbi' && pillars.length === 0) return bad(`${n} needs at least one pillar (sentiment, behaviour or intent)`);
    if (mode !== 'sbi' && pillars.length > 0) return bad(`${n}: pillars are only used in SBI surveys`);
    if (q.required !== undefined && typeof q.required !== 'boolean') return bad(`${n}: "required" must be true or false`);
    if (q.allow_comment !== undefined && typeof q.allow_comment !== 'boolean') return bad(`${n}: "allow_comment" must be true or false`);
  }
  return OK;
}

/** Distribution step. Only link is live; email/restricted/embed are future phases. */
export function validateDistribution(body) {
  if (!body || typeof body !== 'object') return bad('Send the distribution settings as a JSON object');
  if (!CHANNELS.includes(body.channel)) return bad('Choose how to share the survey');
  if (!ACTIVE_CHANNELS.includes(body.channel)) return bad('This channel is available in a future phase.');
  if (body.max_responses !== undefined && body.max_responses !== null) {
    const m = body.max_responses;
    if (!Number.isInteger(m) || m < 1 || m > LIMITS.maxResponses) return bad('Response limit must be a whole number from 1 to 1,000,000');
  }
  for (const k of ['anonymous', 'one_per_user']) {
    if (body[k] !== undefined && typeof body[k] !== 'boolean') return bad(`"${k}" must be true or false`);
  }
  return validateAudience(body);
}

/** Optional audience size (rubric v2 distribution base). Below 15 is allowed but flagged in the report. */
export function validateAudience(body) {
  const a = body?.audience_size;
  if (a === undefined || a === null) return OK;
  if (!Number.isInteger(a) || a < LIMITS.audienceMin || a > LIMITS.audienceMax) {
    return bad('Audience size must be a whole number from 1 to 1,000,000');
  }
  return OK;
}

/**
 * D-52 "You tell us": a choice question with three or more options invites an
 * optional comment in the respondent's own words. Rating, 0-10 and two-option
 * (yes/no style) questions don't; written questions already are words.
 * allow_comment = true still opens any question (kept for older data).
 */
export const COMMENT_MIN_OPTIONS = 3;
export const takesComment = (q) => q?.allow_comment === true
  || (q?.type === 'mc' && Array.isArray(q.options) && q.options.length >= COMMENT_MIN_OPTIONS);

/** One respondent answer against its question. */
export function validateAnswer(question, answer) {
  const a = answer || {};
  const empty = a.value === undefined || a.value === null || (isStr(a.value) && a.value.trim() === '');
  if (empty) return question.required ? bad(`Please answer: "${question.text}"`) : OK;
  const v = a.value;
  switch (question.type) {
    case 'rating':
      if (!Number.isInteger(v) || v < 1 || v > 5) return bad('Ratings are 1 to 5');
      break;
    case 'nps':
      if (!Number.isInteger(v) || v < 0 || v > 10) return bad('Scores are 0 to 10');
      break;
    case 'mc':
      if (!isStr(v) || !(question.options || []).includes(v)) return bad('Choose one of the listed options');
      break;
    case 'open':
      if (!isStr(v) || v.length > LIMITS.open) return bad(`Keep written answers under ${LIMITS.open} characters`);
      break;
    default:
      return bad('Unknown question type');
  }
  if (a.comment !== undefined && a.comment !== null) {
    if (!takesComment(question)) return bad('This question does not take a comment');
    if (!isStr(a.comment) || a.comment.length > LIMITS.comment) return bad(`Keep comments under ${LIMITS.comment} characters`);
  }
  return OK;
}

export function parsePagination({ limit, offset } = {}) {
  const l = Number.parseInt(limit, 10);
  const o = Number.parseInt(offset, 10);
  return {
    limit: Number.isFinite(l) ? Math.min(Math.max(l, 1), 100) : 20,
    offset: Number.isFinite(o) && o > 0 ? o : 0,
  };
}

const SORTS = Object.freeze({
  newest: 's.created_at DESC, s.id DESC',
  oldest: 's.created_at ASC, s.id ASC',
  most_responses: 'response_count DESC, s.created_at DESC, s.id DESC',
});

/** The ONLY string ever interpolated into SQL — a closed whitelist. */
export function resolveSort(key) {
  return SORTS[key] || SORTS.newest;
}
