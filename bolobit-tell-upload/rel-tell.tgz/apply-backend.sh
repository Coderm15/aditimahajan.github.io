#!/bin/bash
# D-52 "Or you tell us!" comments: 3 replaced backend files. Checks every replaced server file
# is still the last released version (OPS §10.1 item 10) before touching anything.
set -euo pipefail
REL=$(cd "$(dirname "$0")" && pwd); B=/home/ubuntu/backend/src; KEEP=/home/ubuntu/backend/_replaced-20261124-tell
declare -A PRE=( [controllers/publicSurveyController.js]=b740f436ab1c [services/verification.js]=0fafdf11d1ad [utils/surveyValidation.js]=b4f92cac0e51 )
declare -A NEW=( [controllers/publicSurveyController.js]=83eb18af7c63 [services/verification.js]=5572f9a9fd2a [utils/surveyValidation.js]=4e9130632ba7 )
for f in "${!PRE[@]}"; do got=$(sha256sum "$B/$f" | cut -c1-12); [ "$got" = "${PRE[$f]}" ] || { echo "STOPPED: $f on the server is $got, expected ${PRE[$f]}. Nothing was changed."; exit 2; }; done
for f in "${!NEW[@]}"; do got=$(sha256sum "$REL/src/$f" | cut -c1-12); [ "$got" = "${NEW[$f]}" ] || { echo "STOPPED: release copy of $f is $got, not the tested file. Nothing was changed."; exit 2; }; node --check "$REL/src/$f"; done
mkdir -p "$KEEP/controllers" "$KEEP/services" "$KEEP/utils"; for f in "${!PRE[@]}"; do cp -p "$B/$f" "$KEEP/$f"; done
for f in "${!NEW[@]}"; do cp "$REL/src/$f" "$B/$f"; cmp -s "$REL/src/$f" "$B/$f" || { echo "COPY MISMATCH $f"; exit 3; }; done
echo "applied 3 files; previous copies in $KEEP"
